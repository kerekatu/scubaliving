import React from 'react'

const ContactPage = () => (
  <main className="container sub">
    <div className="section">
      <h2 className="heading-2">Kontakt</h2>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Porro, eaque!
        Quia rerum quod labore. Nostrum fugit cumque, eius laudantium eaque eos
        quas harum cupiditate aut rerum atque quo minus molestias.
      </p>
    </div>
  </main>
)

export default ContactPage
