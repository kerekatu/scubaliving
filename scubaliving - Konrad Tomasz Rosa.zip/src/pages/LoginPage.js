import React from 'react'

import Login from '../components/Auth/Login'

const LoginPage = () => <Login />

export default LoginPage
