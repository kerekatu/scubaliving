import React from 'react'

import Equipment from '../components/Equipment/Equipment'

const EquipmentPage = () => (
  <main className="container sub">
    <Equipment />
  </main>
)

export default EquipmentPage
