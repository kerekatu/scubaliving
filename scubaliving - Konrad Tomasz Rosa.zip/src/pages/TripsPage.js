import React from 'react'

import Trips from '../components/Trips/Trips'

const TripsPage = () => (
  <main className="container sub">
    <Trips />
  </main>
)

export default TripsPage
