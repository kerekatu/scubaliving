import React from 'react'

const AboutPage = () => (
  <main className="container sub">
    <div className="section">
      <h2 className="heading-2">Om Os</h2>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi
        excepturi doloribus et illum ad, dolore exercitationem. Porro cumque
        esse sapiente soluta nesciunt adipisci culpa, eveniet tempore
        consectetur voluptas, rem veniam.
      </p>
    </div>
  </main>
)

export default AboutPage
