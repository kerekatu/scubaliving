import React from 'react'

import Courses from '../components/Courses/Courses'

const CoursesPage = () => (
  <main className="container sub">
    <Courses />
  </main>
)

export default CoursesPage
