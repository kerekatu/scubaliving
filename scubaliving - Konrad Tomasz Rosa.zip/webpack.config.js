module.exports = require('./webpack/webpack.dev.js')
